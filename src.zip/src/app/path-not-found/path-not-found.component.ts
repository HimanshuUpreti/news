import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-path-not-found',
  templateUrl: './path-not-found.component.html',
  styleUrls: ['./path-not-found.component.css']
})
export class PathNotFoundComponent implements OnInit {
  public a = 'FitTech';
  constructor() { }

  ngOnInit(): void {
  }


}
