import { Component, OnInit, HostListener } from '@angular/core';
import { ServiceService } from './service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  big = true;
  small = false;
  totalCases = 0;
  constructor(private serv: ServiceService) {}
  innerWidth;
  ngOnInit(): void {
  }
  @HostListener('window:resize', ['$event'])
onResize(event) {
  this.innerWidth = window.innerWidth;
  if (this.innerWidth <= 500) {
    this.big = false;
    this.small = true;
  }
  if (this.innerWidth > 500) {
    this.big = true;
    this.small = false;
  }
}
}
